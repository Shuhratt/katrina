<div class="related_ads">         
    
	<h2><strong><?php _e("Related Ads", "katrina"); ?></strong></h2>
	    <?php if( osc_count_items() == 0) { ?>
		<p class="empty"><?php _e("No Related Ads", "katrina"); ?></p>
	    <?php } else { ?>
		
		<?php while(osc_has_items()) { ?>
            <div class="item">
                <?php if( osc_images_enabled_at_items() ) { ?>
                <div class="photo-item">
                     <?php if(osc_count_item_resources()) { ?>
                        <a href="<?php echo osc_item_url(); ?>" class="thumb"><img src="<?php echo osc_resource_thumbnail_url(); ?>" width="75" height="56" title="<?php echo osc_item_title(); ?>" alt="<?php echo osc_item_title(); ?>" /></a>
                    <?php } else { ?>
                        <img src="<?php echo osc_current_web_theme_url('images/no_photo.png'); ?>" title="" alt="" />
                    <?php } ?>
                   </div>
                 <?php } ?>
                 <div class="text">
                     <h3 class="normal">
                         <a href="<?php echo osc_item_url(); ?>"><?php echo osc_highlight(osc_item_title(), 25); ?></a>
                     </h3>
						<p class="price"> <?php echo osc_item_formated_price(); ?> </p>
                    	<div class="prem-lab">
							  <?php if(osc_item_is_premium()) { ?><span class="premium"></span>  <?php } ?>
						</div >
                 </div >
             </div>
         
        <?php } ?>
		<?php } ?>
		</div>		
